(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	const organisationApi = __webpack_require__(1);
	const user = __webpack_require__(8);
	const lambda = __webpack_require__(7);

	exports.handler = (event, context, callback) => {

	    try {

	        const userId = lambda.getUserId(event);

	        user.getUserOrganisation(userId, ['organisationId'])
	            .then(
	                userOrganisation => organisationApi.get(userOrganisation.organisationId),
	                error => lambda.handleError(error, callback, 'Could not fetch user organisation.')
	            )
	            .then(
	                organisation => lambda.handleSuccess(organisation, callback),
	                error => lambda.handleError(error, callback, 'Could not fetch organisation.')
	            );

	    } catch (error) {

	        lambda.handleError(error, callback);
	    }
	};


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	const uuid = __webpack_require__(2);
	const {organisationParams} = __webpack_require__(3);
	const dynamo            = __webpack_require__(4);

	module.exports = {
	    get: getOrganisation,
	    create: createOrganisation,
	    list:listOrganisations,
	    update: updateOrganisation,
	    remove: deleteOrganisation,
	};


	function getOrganisation(organisationId) {

	    return new Promise((resolve, reject) => {

	        try {

	            const params = {
	                Key: {
	                    organisationId: organisationId
	                }
	            };

	            Object.assign(params, organisationParams);

	            dynamo.get(params, resolve, reject);

	        } catch (error) {

	            reject(new Error(error));
	        }
	    });
	}


	function createOrganisation(attribute) {

	    try {
	        const params = {
	            Item: attribute
	        };

	        params.Item.organisationId  = uuid();

	        Object.assign(params, organisationParams);

	        return (new Promise((resolve, reject) => dynamo.create(params, resolve, reject)));

	    } catch (error) {

	        return Promise.reject(error);
	    }
	}

	function listOrganisations() {


	    try {

	        let params = Object.assign({}, organisationParams);

	        console.log(params);


	        return (new Promise((resolve, reject) => dynamo.scan(params, resolve, reject)));

	    } catch (error) {

	        return Promise.reject(error);
	    }


	}

	function updateOrganisation(organisationId, wasteFacilityId, vehicle) {

	    try {

	        delete vehicle.organisationId;
	        delete vehicle.wasteFacilityId;

	        let params = {
	            Key: {
	                organisationId:  organisationId,
	                wasteFacilityId: wasteFacilityId
	            }
	        };

	        dynamo.addUpdateToParams(vehicle, params);

	        Object.assign(params, organisationParams);

	        return (new Promise((resolve, reject) => dynamo.update(params, resolve, reject)));

	    } catch (error) {

	        return Promise.reject(error);
	    }
	}

	function deleteOrganisation(organisationId, wasteFacilityId) {

	    try {

	        const params = {
	            Key: {
	                organisationId:  organisationId,
	                wasteFacilityId: wasteFacilityId
	            }
	        };

	        Object.assign(params, organisationParams);

	        return (new Promise((resolve, reject) => dynamo.delete(params, resolve, reject)));

	    } catch (error) {

	        return Promise.reject(error);
	    }
	}

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	module.exports = require("uuid");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

	'use strict';

	module.exports.hotelParams      = {
	    TableName: 'hotels'
	};
	module.exports.userOrganisationParams      = {
	    TableName: 'userOrganisations'
	};
	module.exports.organisationParams      = {
	    TableName: 'organisations'
	};



/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

	const documentClient = __webpack_require__(5);

	module.exports = {
	    scan:                    scanItems,
	    list:                    listItems,
	    get:                     getItem,
	    getFirst:                getFirst,
	    create:                  createItem,
	    update:                  updateItem,
	    delete:                  deleteItem,
	    addUpdateToParams:       addUpdateToParams,
	    setProjectionExpression: setProjectionExpression
	};

	function getFirst(params, resolve, reject) {

	    try {
	        new Promise((resolve, reject) => listItems(params, resolve, reject))
	            .then(
	                items => resolve(items.pop()),
	                error => reject(new Error(error))
	            );
	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function scanItems(params, resolve, reject) {

	    try {

	        documentClient.scan(params).promise().then(
	            result => resolve(result.Items),
	            error => reject(new Error(error))
	        );

	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function listItems(params, resolve, reject) {

	    try {

	        documentClient.query(params).promise().then(
	            result => resolve(result.Items),
	            error => reject(new Error(error))
	        );

	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function getItem(params, resolve, reject) {

	    try {

	        documentClient.get(params).promise().then(
	            result => resolve(result.Item),
	            error => reject(new Error(error))
	        );
	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function createItem(params, resolve, reject) {

	    try {

	        documentClient.put(params).promise().then(
	            result => resolve(params.Item),
	            error => reject(new Error(error))
	        );

	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function updateItem(params, resolve, reject) {

	    try {

	        Object.assign(params, {ReturnValues: 'ALL_NEW'});

	        documentClient.update(params).promise().then(
	            result => resolve(result.Attributes),
	            error => reject(new Error(error))
	        );

	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function deleteItem(params, resolve, reject) {

	    try {

	        Object.assign(params, {ReturnValues: 'ALL_OLD'});

	        documentClient.delete(params).promise().then(
	            result => resolve(result.Attributes),
	            error => reject(new Error(error))
	        );

	    } catch (error) {

	        reject(new Error(error));
	    }
	}

	function addUpdateToParams(update, params) {

	    let attributeValues = {};

	    let updateExpression = 'set ' + Object.keys(update).map(key => {
	        return ' ' + key + ' = :' + key;
	    }).join(', ');

	    for (let key in update) {

	        attributeValues[':' + key] = attributeValue(update[key]);
	    }

	    params.UpdateExpression          = updateExpression;
	    params.ExpressionAttributeValues = attributeValues;

	    return params;
	}

	function setProjectionExpression(params, projectionExpression) {

	    !params.hasOwnProperty('ExpressionAttributeNames') && (params.ExpressionAttributeNames = {});
	    !params.hasOwnProperty('ProjectionExpression') && (params.ProjectionExpression = []);

	    projectionExpression.map(value => {

	        let name = '#' + value;

	        params.ExpressionAttributeNames[name] = value;
	        params.ProjectionExpression.push(name);
	    });
	}

	function attributeValue(value) {

	    return (!!value || isNumeric(value)) && value || null;
	}

	function isNumeric(value) {

	    return Number(parseFloat(value)) === value;
	}

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	const AWS            = __webpack_require__(6);
	const documentClient = new AWS.DynamoDB.DocumentClient();

	module.exports = documentClient;


/***/ }),
/* 6 */
/***/ (function(module, exports) {

	module.exports = require("aws-sdk");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	const uuid = __webpack_require__(2);

	module.exports = {
	    getUserId:        getUserId,
	    checkUserGroup:   checkUserGroup,
	    handleSuccess:    handleSuccess,
	    handleError:      handleError,
	    extractNew:       extractNew,
	    extractData:      extractData,
	    extractUserAgent: extractUserAgent,
	    getPathParam:     getPathParam
	};

	function getUserId(event) {

	    try {
	        return event.requestContext.authorizer.claims.sub;

	    } catch (error) {

	        throw new Error(error);
	    }
	}

	function checkUserGroup(event, group) {

	    return new Promise((resolve, reject) => {

	        try {

	            let groups = event.requestContext.authorizer.claims['cognito:groups'].split(',');

	            groups.indexOf(group) !== -1 && resolve() || reject();

	        } catch (error) {

	            reject(new Error(error));
	        }
	    });
	}

	function handleSuccess(data, callback) {

	    let statusCode = (!!data) ? 200 : 404;

	    let response = {
	        statusCode: statusCode,
	        headers:    {
	            'Access-Control-Allow-Origin': '*'
	        },
	        body:       JSON.stringify(data)
	    };

	    !!process.env.hasOwnProperty('version') && Object.assign(
	        response.headers,
	        {
	            'Access-Control-Expose-Headers': 'Content-Version',
	            'Content-Version':               process.env.version
	        });

	    callback(null, response);
	}

	function handleError(error, callback, message) {

	    console.log('error', error);
	    console.log('message', message);

	    message = message || error;

	    let response = {
	        statusCode: 500,
	        headers:    {'Access-Control-Allow-Origin': '*'},
	        body:       JSON.stringify({error: message})
	    };

	    callback(null, response);
	}

	function extractNew(event, idField) {

	    let data = extractData(event);

	    data[idField] = uuid();

	    return data;
	}

	function extractData(event) {

	    return JSON.parse(event.body);
	}

	function getPathParam(param, event) {

	    try {

	        return event.pathParameters[param];

	    } catch (error) {

	        return null;
	    }

	}

	function extractUserAgent(event) {

	    return event.headers['User-Agent'];
	}


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	const { userOrganisationParams } = __webpack_require__(3);
	const dynamo            = __webpack_require__(4);

	module.exports = {
	    getUserOrganisation: getUserOrganisation
	};

	function getUserOrganisation(userId, attributes) {

	    return new Promise((resolve, reject) => {

	        try {

	            let params = {
	                Key:             {userId: userId},
	                AttributesToGet: attributes
	            };

	            Object.assign(params, userOrganisationParams);

	            new Promise((resolve, reject) => dynamo.get(params, resolve, reject))
	                .then(
	                    organisation => !!organisation && resolve(organisation) || reject(new Error('No Organisation found.')),
	                    error => reject(new Error(error))
	                );

	        } catch (error) {

	            reject(new Error(error));
	        }
	    });
	}

/***/ })
/******/ ])));